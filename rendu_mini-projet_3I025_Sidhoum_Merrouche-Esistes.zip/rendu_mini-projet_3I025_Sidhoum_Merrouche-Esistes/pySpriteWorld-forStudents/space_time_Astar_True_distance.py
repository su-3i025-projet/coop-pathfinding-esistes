import math
import heapq


class Node():
    def __init__(self, parent=None, position=None):
        self.parent = parent
        self.position = position
        self.g = 0
        self.h = 0
        self.f = 0

    def __lt__(self, other):
        return self.f < other.f

    def getG(self):
        return self.g


class Node_time():
    def __init__(self, parent=None, position=None):
        self.parent = parent
        self.position = position
        self.g = 0
        self.h = 0
        self.f = 0

    def __lt__(self, other):
        return self.f < other.f

# permet de calculer l'heuristique true distance


class True_distance():
    def __init__(self, initStates, pos1, goalStates, pos2, wallCopie, maxRow, maxCol):
        self.initStates = initStates
        self.pos1 = pos1
        self.goalStates = goalStates
        self.pos2 = pos2
        self.wallCopie = wallCopie
        self.closed_list = {}
        self.maxCol = maxCol
        self.maxRow = maxRow

    def initialise(self):
        # Create start and end node
        self.start_node = Node(None, self.goalStates[self.pos2])
        self.start_node.g = self.start_node.h = self.start_node.f = 0
        self.end_node = Node(None, self.initStates[self.pos1])
        self.end_node.g = self.end_node.h = self.end_node.f = 0

        # Initialize best node
        self.bestNoeud = self.start_node

        # Add the start node to the open list
        self.open_list = [self.start_node]
    # renvoie l'heuristique true distance de la position passe en parametre

    def getTrueDistance(self, position):
        if position in self.closed_list:
            return self.closed_list[position]
        else:
            trouv = False
            while ((len(self.open_list) > 0) and (not trouv)):
                # Get the current best node
                self.bestNoeud = heapq.heappop(self.open_list)
                self.closed_list[self.bestNoeud.position] = self.bestNoeud.g
                if self.bestNoeud.position == position:
                    trouv = True

                # Generate children
                children = []
                for new_position in [(0, -1), (0, 1), (-1, 0), (1, 0)]:  # Adjacent squares

                    # Get node position
                    node_position = (
                        self.bestNoeud.position[0] + new_position[0], self.bestNoeud.position[1] + new_position[1])

                    # Make sure within range
                    next_col = node_position[1]
                    next_row = node_position[0]

                    # Make sure walkable area
                    if ((next_row, next_col) in self.wallCopie) or next_row < 0 or next_row > self.maxRow-1 or next_col < 0 or next_col > self.maxCol-1:
                        # print(next_col,next_row)
                        continue

                    # Create new node
                    new_node = Node(self.bestNoeud, node_position)

                    # Append
                    children.append(new_node)

                # Loop through children

                for child in children:
                    con = False
                    # Child is in the closed list
                    if child.position in self.closed_list:
                        con = True

                    # Create the f, g, and h values
                    child.g = self.bestNoeud.g + 1
                    child.h = math.fabs((child.position[0] - self.end_node.position[0])) + math.fabs(
                        (child.position[1] - self.end_node.position[1]))
                    child.f = child.g + child.h

                    # Child is already in the open list
                    for open_node in self.open_list:
                        if child.position == open_node.position and child.g >= open_node.g:
                            con = True

                    # Add the child to the open list
                    if self.bestNoeud.position == (0, 14):
                        print(child.position)
                    if con == False:
                        heapq.heappush(self.open_list, child)
                if trouv == True:
                    return self.bestNoeud.g

#########################################################################################################################################
# initStates : les positions initiales des joueurs
# pos1 : index dans iniStates du joueurs concérné
# goalStates : les positions des fioles
# pos2 : index dans goalStates du but de ce joueur
# wallStates : les positions ou il ya des obstacles
# reservation : liste des positions (x,y,t) deja occupées par d'autres agents
# maxRow et maxCol : taille de la Carte


def space_time_Astar_True_Distance(initStates, pos1, goalStates, pos2, reservation, wallCopie, maxRow, maxCol):
    # On cree le noeud de début et le noeud déstination
    start_node = Node_time(None, (initStates[pos1][0], initStates[pos1][1], 0))
    start_node.g = start_node.h = start_node.f = 0
    end_node = Node(None, goalStates[pos2])
    end_node.g = end_node.h = end_node.f = 0

    # on initialise la recherche auxiliaire
    true_distance = True_distance(
        initStates, pos1, goalStates, pos2, wallCopie, maxRow, maxCol)
    true_distance.initialise()

    # On initialise la résérve et la frontière
    open_list = []  # frontiere
    closed_list = {}  # reserve
    bestNoeud = start_node
    chemin = []  # le chemin est initialement vide,on suppose au debut qu'il n'existe pas

    # On ajoute le noeud de début à la frontière
    open_list = [start_node]

    # Tant qu'on a pas trouvé la déstination et qu'il reste des noeuds à étendre
    goal = False
    while ((len(open_list) > 0) and (goal == False)):
        print("Astar", len(open_list), " ", len(closed_list))
        # On resupére le meilleur noeud , qui minimise la valeur de f
        bestNoeud = heapq.heappop(open_list)
        if not (bestNoeud.position in closed_list.keys()):
            closed_list[bestNoeud.position] = bestNoeud.g

        # Si on trouve la déstination, on construit le chemin
        if (bestNoeud.position[0], bestNoeud.position[1]) == end_node.position:
            path = []
            current = bestNoeud
            while current is not None:
                reservation.append(current.position)
                reservation.append(
                    (current.position[0], current.position[1], current.position[2]+1))
                reservation.append(
                    (current.position[0], current.position[1], current.position[2]-1))
                path.append((current.position[0], current.position[1]))
                current = current.parent
            chemin = path[::-1]  # reversed path
            goal = True

        # On étend le meilleur noeuds
        children = []
        for new_position in [(0, -1), (0, 1), (-1, 0), (1, 0), (0, 0)]:  # Adjacent squares

            # On recupére la position du noeud candidat
            node_position = (
                bestNoeud.position[0] + new_position[0], bestNoeud.position[1] + new_position[1], bestNoeud.position[2] + 1)

            next_col = node_position[1]
            next_row = node_position[0]
            next_time = node_position[2]

            # On s'assure que cette position est légale
            if ((next_row, next_col) in wallCopie) or (node_position in reservation) or next_row < 0 or next_row > maxRow-1 or next_col < 0 or next_col > maxCol-1:
                # print(next_col,next_row)
                continue

            # On créé ce noeud
            new_node = Node_time(bestNoeud, node_position)

            # Append
            children.append(new_node)

        # Loop through children

        for child in children:
            con = False
            # Si il est dans la résérve
            if child.position in closed_list:
                con = True

            # On créé f, g, et h
            child.g = bestNoeud.g + 1
            child.h = true_distance.getTrueDistance(
                (child.position[0], child.position[1]))
            child.f = child.g + child.h

            # Si il est dans la frontiére et qu'il n'améliore pas le g
            for open_node in open_list:
                if child.position == open_node.position and child.g >= open_node.g:
                    con = True

            # On l'ajoute à la frontière
            if con == False:
                heapq.heappush(open_list, child)
    return chemin
