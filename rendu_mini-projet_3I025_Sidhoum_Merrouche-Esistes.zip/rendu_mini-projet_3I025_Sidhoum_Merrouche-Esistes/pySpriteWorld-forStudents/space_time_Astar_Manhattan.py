import math
import heapq

# Represente un noeud de l'arbre d'etat du A* spatial


class Node():
    def __init__(self, parent=None, position=None):
        self.parent = parent
        self.position = position
        self.g = 0
        self.h = 0
        self.f = 0

    def __lt__(self, other):
        return self.f < other.f

    def getG(self):
        return self.g


# Represente un noeud de l'arbre d'etat du A* spatio-temporel
class Node_time():
    def __init__(self, parent=None, position=None):
        self.parent = parent
        self.position = position
        self.g = 0
        self.h = 0
        self.f = 0

    def __lt__(self, other):
        return self.f < other.f
#########################################################################################################################################


# initStates : les positions initiales des joueurs
# pos1 : index dans iniStates du joueurs concérné
# goalStates : les positions des fioles
# pos2 : index dans goalStates du but de ce joueur
# wallStates : les positions ou il ya des obstacles
# reservation : liste des positions (x,y,t) deja occupées par d'autres agents
# maxRow et maxCol : taille de la Carte

def space_time_Astar_Manhattan(initStates, pos1, goalStates, pos2, reservation, wallCopie, maxRow, maxCol):
    # On cree le noeud de début et le noeud déstination
    start_node = Node_time(
        None, (initStates[pos1][0], initStates[pos1][1], 0))
    start_node.g = start_node.h = start_node.f = 0
    end_node = Node(None, goalStates[pos2])
    end_node.g = end_node.h = end_node.f = 0

    # On initialise la résérve et la frontière
    open_list = []  # frontiere
    closed_list = {}  # reserve
    bestNoeud = start_node
    chemin = []  # le chemin est initialement vide,on suppose au debut qu'il n'existe pas

    # On ajoute le noeud de début à la frontière
    open_list = [start_node]

    # Tant qu'on a pas trouvé la déstination et qu'il reste des noeuds à étendre
    goal = False
    while ((len(open_list) > 0) and (goal == False)):
        print("Astar", len(open_list), " ", len(closed_list))
        # On resupére le meilleur noeud , qui minimise la valeur de f
        bestNoeud = heapq.heappop(open_list)
        print(bestNoeud.position, " ", bestNoeud.g)
        print(bestNoeud.position in closed_list.keys())
        closed_list[bestNoeud.position] = bestNoeud.g

        # Si on trouve la déstination, on construit le chemin
        if (bestNoeud.position[0], bestNoeud.position[1]) == end_node.position:
            path = []
            current = bestNoeud
            while current is not None:
                reservation.append(current.position)
                reservation.append(
                    (current.position[0], current.position[1], current.position[2]+1))
                reservation.append(
                    (current.position[0], current.position[1], current.position[2]-1))
                path.append((current.position[0], current.position[1]))
                current = current.parent
            chemin = path[::-1]  # reversed path
            goal = True

        # On étend le meilleur noeuds
        children = []
        for new_position in [(0, -1), (0, 1), (-1, 0), (1, 0)]:  # Adjacent squares

            # On recupére la position du noeud candidat
            node_position = (
                bestNoeud.position[0] + new_position[0], bestNoeud.position[1] + new_position[1], bestNoeud.position[2] + 1)

            next_col = node_position[1]
            next_row = node_position[0]

            # On s'assure que cette position est légale
            if ((next_row, next_col) in wallCopie) or (node_position in reservation) or next_row < 0 or next_row > maxRow-1 or next_col < 0 or next_col > maxCol-1:
                continue

            # On créé ce noeud
            new_node = Node_time(bestNoeud, node_position)

            # Append
            children.append(new_node)

        # Loop through children

        for child in children:
            con = False
            # Si il est dans la résérve
            if child.position in closed_list:
                con = True

            # On créé f, g, et h
            child.g = bestNoeud.g + 1
            child.h = math.fabs((child.position[0] - end_node.position[0])) + math.fabs(
                (child.position[1] - end_node.position[1]))
            child.f = child.g + child.h

            # Si il est dans la frontiére et qu'il n'améliore pas le g
            for open_node in open_list:
                if child.position == open_node.position and child.g >= open_node.g:
                    con = True

            # On l'ajoute à la frontière
            if con == False:
                heapq.heappush(open_list, child)
    return chemin
