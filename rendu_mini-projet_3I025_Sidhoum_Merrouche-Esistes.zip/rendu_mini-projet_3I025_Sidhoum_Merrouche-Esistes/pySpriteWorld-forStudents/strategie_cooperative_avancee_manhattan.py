# -*- coding: utf-8 -*-

# Nicolas, 2015-11-18

from __future__ import absolute_import, print_function, unicode_literals
from gameclass import Game, check_init_game_done
from spritebuilder import SpriteBuilder
from players import Player
from sprite import MovingSprite
from ontology import Ontology
from itertools import chain
import pygame
import glo

import random
import numpy as np
import sys
import copy
from Astar import Astar
from intersection import intersection
from space_time_Astar_Manhattan import space_time_Astar_Manhattan
from space_time_Astar_True_distance import space_time_Astar_True_Distance
import time

# ---- ---- ---- ---- ---- ----
# ---- Main                ----
# ---- ---- ---- ---- ---- ----

game = Game()


def init(_boardname=None):
    global player, game
    # pathfindingWorld_MultiPlayer4
    name = _boardname if _boardname is not None else 'pathfindingWorld_MultiPlayer8'
    game = Game('Cartes/' + name + '.json', SpriteBuilder)
    game.O = Ontology(True, 'SpriteSheet-32x32/tiny_spritesheet_ontology.csv')
    game.populate_sprite_names(game.O)
    game.fps = 20  # frames per second
    game.mainiteration()
    game.mask.allow_overlaping_players = True
    #player = game.player


def main():

    # for arg in sys.argv:
    # On recupere le nombre de tops d'horloge (50 par defaut)
    iterations = 50  # default
    if len(sys.argv) == 2:
        iterations = int(sys.argv[1])
    print("Iterations: ")
    print(iterations)

    init()

    # -------------------------------
    # Initialisation
    # -------------------------------
    print("nombre de colonnes : ", game.spriteBuilder.colsize)
    players = [o for o in game.layers['joueur']]
    nbPlayers = len(players)
    score = [0]*nbPlayers
    maxCol = game.spriteBuilder.colsize
    maxRow = game.spriteBuilder.rowsize
    # on localise tous les états initiaux (loc du joueur)
    initStates = [o.get_rowcol() for o in game.layers['joueur']]
    print("Init states:", initStates)

    # on localise tous les objets ramassables
    goalStates = [o.get_rowcol() for o in game.layers['ramassable']]
    print("Goal states:", goalStates)

    # on localise tous les murs
    wallStates = [w.get_rowcol() for w in game.layers['obstacle']]
    #print ("Wall states:", wallStates)

    # -------------------------------
    # Placement aleatoire des fioles
    # -------------------------------

    # on donne a chaque joueur une fiole a ramasser(dans l'ordre initial)
    playersCopie = copy.deepcopy(initStates)
    posPlayers = copy.deepcopy(initStates)
    goalsCopie = copy.deepcopy(goalStates)
    wallCopie = copy.deepcopy(wallStates)

    # Si il y'a plus de joueurs que de fioles , on selectionne des joueurs
    if nbPlayers > len(goalsCopie):
        nbPlayers = len(goalsCopie)
    # -------------------------------
    # Construction de la space-time map
    # et de la table de de reservation
    # -------------------------------
    # reservation est une liste qui contient les triplets (x,y,t) interdits (qui sont occupees par un joueur)
    reservation = []
    for pos in initStates:
        reservation.append((pos[0], pos[1], 0))

    # -------------------------------
    # Recherche des chemins optimaux
    # et mise a jour de la table de reservation (se fait dans A*)
    # -------------------------------

    chemins = []
    found = []
    tmps1 = time.clock()
    for i in range(nbPlayers):
        elt = space_time_Astar_Manhattan(
            playersCopie, i, goalsCopie, i, reservation, wallCopie, maxRow, maxCol)
        # Si Astar renvoie vide la carte est impossible (Pas de chemin trouvé)
        if elt == []:
            print("Carte Imossible")
            return "Carte Imposible"
        chemins.append(elt)
        found.append(False)
    tmps2 = time.clock()
    # -------------------------------
    # Boucle principale de déplacements
    # -------------------------------

    # -------------------------------
    # Boucle principale de déplacements
    # -------------------------------
    cpt = 0
    iteration_valide = False
    for i in range(iterations):
        iteration_valide = False
        # on fait bouger chaque joueur séquentiellement
        for j in range(nbPlayers):
            if found[j] == True:
                continue
            iteration_valide = True
            # on recupere la position initiale du joueur
            row, col = posPlayers[j]
            # on recupere la prochaine position du joueur
            next_row = chemins[j][i][0]
            next_col = chemins[j][i][1]
            # Si la position ne pose aucun probleme
            if ((next_row, next_col) not in wallStates) and next_row >= 0 and next_row < maxRow and next_col >= 0 and next_col < maxCol:
                players[j].set_rowcol(next_row, next_col)
                print("pos :", j, next_row, next_col)
                game.mainiteration()

                col = next_col
                row = next_row
                posPlayers[j] = (row, col)

            # si on a  trouvé un objet on le ramasse
            if (row, col) == goalsCopie[j]:
                found[j] = True
                o = players[j].ramasse(game.layers)
                game.mainiteration()
                print("Objet trouvé par le joueur ", j)
                # on enlève ce goalState de la liste
                goalStates.remove((row, col))
                score[j] += 1
        if iteration_valide:
            cpt += 1

    print("scores:", score)
    print("iterations : ", cpt)
    print("temps de routage : ", tmps2-tmps1)
    quit()


if __name__ == '__main__':
    main()
