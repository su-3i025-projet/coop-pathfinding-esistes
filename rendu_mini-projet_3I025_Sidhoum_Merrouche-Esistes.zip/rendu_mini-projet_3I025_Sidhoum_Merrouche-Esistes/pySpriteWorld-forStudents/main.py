import Astar as a
import DiscreteWorld-coopPathFinding as ds
ds.main()
