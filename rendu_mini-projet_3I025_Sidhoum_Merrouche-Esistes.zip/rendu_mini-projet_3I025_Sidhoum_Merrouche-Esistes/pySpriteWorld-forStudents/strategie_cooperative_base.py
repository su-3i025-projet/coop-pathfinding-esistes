# -*- coding: utf-8 -*-

# Nicolas, 2015-11-18

from __future__ import absolute_import, print_function, unicode_literals
from gameclass import Game,check_init_game_done
from spritebuilder import SpriteBuilder
from players import Player
from sprite import MovingSprite
from ontology import Ontology
from itertools import chain
import pygame
import glo

import random 
import numpy as np
import sys
import copy
from Astar import Astar
from intersection import intersection
import time

# ---- ---- ---- ---- ---- ----
# ---- Main                ----
# ---- ---- ---- ---- ---- ----

game = Game()

def init(_boardname=None):
    global player,game
    # pathfindingWorld_MultiPlayer4
    name = _boardname if _boardname is not None else 'pathfindingWorld_MultiPlayer8'
    game = Game('Cartes/' + name + '.json', SpriteBuilder)
    game.O = Ontology(True, 'SpriteSheet-32x32/tiny_spritesheet_ontology.csv')
    game.populate_sprite_names(game.O)
    game.fps = 40  # frames per second
    game.mainiteration()
    game.mask.allow_overlaping_players = True
    #player = game.player
    
def main():

    #for arg in sys.argv:
    #On recupere le nombre de tops d'horloge (50 par defaut)
    iterations = 50 # default
    if len(sys.argv) == 2:
        iterations = int(sys.argv[1])
    print ("Iterations: ")
    print (iterations)

    init()
    
    #-------------------------------
    # Initialisation
    #-------------------------------
       
    players = [o for o in game.layers['joueur']]
    nbPlayers = len(players)
    score = [0]*nbPlayers
    maxCol = game.spriteBuilder.colsize
    maxRow = game.spriteBuilder.rowsize
    
    # on localise tous les états initiaux (loc du joueur)
    initStates = [o.get_rowcol() for o in game.layers['joueur']]
    print ("Init states:", initStates)
    
    # on localise tous les objets ramassables
    goalStates = [o.get_rowcol() for o in game.layers['ramassable']]
    print ("Goal states:", goalStates)
        
    # on localise tous les murs
    wallStates = [w.get_rowcol() for w in game.layers['obstacle']]
    #print ("Wall states:", wallStates)
    
    #-------------------------------
    # Placement aleatoire des fioles 
    #-------------------------------
    
    # on donne a chaque joueur une fiole a ramasser(dans l'ordre initial)
    playersCopie = copy.deepcopy(initStates)
    posPlayers = copy.deepcopy(initStates)
    goalsCopie = copy.deepcopy(goalStates)
    wallCopie = copy.deepcopy(wallStates)

    #Si il y'a plus de joueurs que de fioles , on selectionne des joueurs
    if nbPlayers>len(goalsCopie) :
        nbPlayers = len(goalsCopie)

    #-------------------------------
    # Recherche des chemins optimaux
    #-------------------------------
    
    chemins = []
    found = []
    tmps1 = time.clock()
    for i in range(nbPlayers):
        elt = Astar(playersCopie, i, goalsCopie,
                    i, wallCopie, maxRow, maxCol)
        # Si Astar renvoie vide la carte est impossible (Pas de chemin trouvé)
        if elt == []:
            print("Carte Imossible")
            return "Carte Imposible"
        chemins.append(elt)
        found.append(False)

    #-------------------------------
    # construction des classes : 
    # appartienent a la meme classe les chemins qui ne se croisent pas
    #-------------------------------

    #classes : est un tebleau de classe
    #classe : est un tableau de chemins
    classes = []
    classes.append([chemins[0]])
    for i in range(1,len(chemins)):
        for j in range(len(classes)):
            insert = True
            for f in range(len(classes[j])):
                if intersection(classes[j][f],chemins[i]) != [] :
                    insert = False
            if insert ==True :
                classes[j].append(chemins[i])
                break
        if insert== False:
            classes.append([chemins[i]])
    tmps2 = time.clock()
    

    #-------------------------------
    # Boucle principale de déplacements 
    #-------------------------------
    cpt = 0
    iteration_valide = False
    for x in range(len(classes)):
        for i in range(iterations):
            iteration_valide = False
            # on fait bouger chaque joueur séquentiellement
            for f in range(len(classes[x])): 
                #on recupere l'index du jouer courant
                j = chemins.index(classes[x][f])
                if found[j] == True :
                    continue
                iteration_valide = True
                #on recupere la position initiale du joueur
                row,col = posPlayers[j]
                #on recupere la prochaine position du joueur
                next_row = chemins[j][i][0]
                next_col = chemins[j][i][1]
                if ((next_row,next_col) not in wallStates) and next_row>=0 and next_row<maxRow and next_col>=0 and next_col<maxCol:
                    players[j].set_rowcol(next_row,next_col)
                    print ("pos :", j, next_row,next_col)
                    game.mainiteration()
        
                    col=next_col
                    row=next_row
                    posPlayers[j]=(row,col)
        
                # si on a  trouvé un objet on le ramasse
                if (row,col) == goalsCopie[j]:
                    found[j] = True
                    o = players[j].ramasse(game.layers)
                    game.mainiteration()
                    print ("Objet trouvé par le joueur ", j)
                    goalStates.remove((row,col)) # on enlève ce goalState de la liste
                    score[j]+=1
            if iteration_valide:
                cpt += 1
            
    print ("scores:", score)
    print("iterations : ",cpt)
    print("temps de routage : ", tmps2-tmps1)
    quit()
    
        
    
   

if __name__ == '__main__':
    main()

