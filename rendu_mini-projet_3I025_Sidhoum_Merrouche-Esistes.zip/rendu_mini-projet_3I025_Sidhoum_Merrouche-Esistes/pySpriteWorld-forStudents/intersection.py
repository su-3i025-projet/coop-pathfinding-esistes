def intersection(lst1, lst2):
    # Retourne l'intersection de la liste lst1 et la liste lst2
    # Le resultat est une liste
    temp = set(lst2)
    lst3 = [value for value in lst1 if value in temp]
    return lst3


"""
#test de la fonction intersection
lst1 = [(2, 19), (3, 19), (4, 19), (4, 18), (4, 17), (4, 16), (4, 15), (4, 14), (5, 14),
        (6, 14), (6, 13), (7, 13), (7, 12), (8, 12), (8, 11), (8, 10), (8, 9), (8, 8), (8, 7)]
lst2 = [(18, 1), (17, 1), (16, 1), (15, 1), (15, 2), (15, 3), (15, 4), (14, 4), (13, 4), (12, 4), (12, 5), (12, 6), (12, 7),
        (12, 8), (12, 9), (12, 10), (12, 11), (12, 12), (12, 13), (12, 14), (12, 15), (12, 16), (12, 17), (12, 18), (12, 19)]

lst3 = [(3, 0), (3, 1), (3, 2), (4, 2), (4, 3), (4, 4), (4, 5), (4, 6),
        (5, 6), (6, 6), (6, 7), (7, 7), (7, 8), (8, 8), (8, 9), (8, 10)]
lst4 = [(19, 16), (19, 15), (19, 14), (18, 14), (17, 14), (16, 14), (15, 14), (14, 14), (13, 14), (13, 13), (13, 12), (13, 11),
        (13, 10), (13, 9), (13, 8), (13, 7), (13, 6), (12, 6), (12, 5), (12, 4), (12, 3), (12, 2), (12, 1), (12, 0), (13, 0)]

print("1 et 2 : ", intersection(lst1, lst2))
print("2 et 3 : ", intersection(lst2, lst3))
print("2 et 4 : ", intersection(lst2, lst4))
print("1 et 3 : ", intersection(lst1, lst3))
print("1 et 4 : ", intersection(lst1, lst4))
"""
