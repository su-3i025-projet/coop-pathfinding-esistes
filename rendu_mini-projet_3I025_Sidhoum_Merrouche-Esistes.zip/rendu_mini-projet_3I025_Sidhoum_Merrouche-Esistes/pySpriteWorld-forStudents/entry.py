class Entry:
    def __init__(self, occupied, position, index, fiole):
        self.occupied = occupied  # boolean qui specifie si cette case est lagale
        self.position = position  # la position spatio-temporelle
        # le joueur qui occupe cette case ,si c'est un obstacle constant alors -1
        self.index = index
        self.fiole = fiole  # indice de la fiole, si cette case ne contient pas de fioles alors vide

    def getOccupied(self):
        return self.occupied

    def getPosition(self):
        return self.position

    def getIndex(self):
        return self.index

    def getFiole(self):
        return self.fiole
