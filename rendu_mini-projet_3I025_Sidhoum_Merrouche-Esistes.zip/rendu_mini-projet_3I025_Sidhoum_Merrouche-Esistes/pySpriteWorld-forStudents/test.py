closed = {}
print(len(closed))
closed[(1, 2, 3)] = 12
print(len(closed))
print((1, 2, 3) in closed)
closed[(1, 2, 3)] = 13
print(len(closed))
print((1, 2, 3) in closed)
closed[(1, 2, 8)] = 156
print(len(closed))
